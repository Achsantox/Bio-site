#!/bin/bash

echo "🚀 The Websites Panel Başlatılıyor..."
echo "=================================="

# Node.js kontrolü
if ! command -v node &> /dev/null; then
    echo "❌ Node.js bulunamadı. Lütfen Node.js yükleyin."
    echo "📥 İndirme: https://nodejs.org/"
    exit 1
fi

# npm kontrolü
if ! command -v npm &> /dev/null; then
    echo "❌ npm bulunamadı. Lütfen npm yükleyin."
    exit 1
fi

echo "✅ Node.js ve npm bulundu"

# package.json kontrolü
if [ ! -f "package.json" ]; then
    echo "❌ package.json bulunamadı. Doğru klasörde olduğunuzdan emin olun."
    exit 1
fi

echo "📦 Bağımlılıklar yükleniyor..."
npm install

if [ $? -eq 0 ]; then
    echo "✅ Bağımlılıklar başarıyla yüklendi"
else
    echo "❌ Bağımlılık yükleme hatası"
    exit 1
fi

echo "🏗️  Proje build ediliyor..."
npm run build

if [ $? -eq 0 ]; then
    echo "✅ Build başarılı"
else
    echo "❌ Build hatası"
    exit 1
fi

echo "🚀 Sunucu başlatılıyor..."
echo "🌐 Panel: http://localhost:3000"
echo "🔐 Giriş: admin / achsanto"
echo "=================================="

npm start
