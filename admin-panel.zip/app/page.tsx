"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  ShoppingCart,
  Play,
  MessageCircle,
  Music,
  Gamepad2,
  Bitcoin,
  Dices,
  Heart,
  Car,
  Home,
  Utensils,
  Plane,
  Shirt,
  GraduationCap,
  CreditCard,
  Brain,
  Trophy,
  Globe,
  Menu,
  X,
  LogOut,
  Search,
  Newspaper,
  Code,
  Briefcase,
  Camera,
  Headphones,
  Users,
  Shield,
  Scale,
} from "lucide-react"

export default function AdminPanel() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (username === "admin" && password === "achsanto") {
      setIsLoggedIn(true)
      setError("")
    } else {
      setError("Kullanıcı adı veya şifre hatalı!")
    }
    setIsLoading(false)
  }

  const handleSiteClick = (url: string) => {
    // URL'yi yeni sekmede aç
    window.open(url, "_blank", "noopener,noreferrer")
  }

  const categories = [
    {
      title: "Sosyal Medya",
      icon: <MessageCircle className="h-5 w-5" />,
      color: "from-blue-600 to-blue-800",
      sites: [
        { name: "Facebook", url: "https://facebook.com" },
        { name: "Twitter", url: "https://twitter.com" },
        { name: "Instagram", url: "https://instagram.com" },
        { name: "LinkedIn", url: "https://linkedin.com" },
        { name: "TikTok", url: "https://tiktok.com" },
        { name: "Discord", url: "https://discord.com" },
        { name: "Telegram", url: "https://telegram.org" },
        { name: "WhatsApp Web", url: "https://web.whatsapp.com" },
        { name: "Snapchat", url: "https://snapchat.com" },
        { name: "Reddit", url: "https://reddit.com" },
      ],
    },
    {
      title: "E-Ticaret Türkiye",
      icon: <ShoppingCart className="h-5 w-5" />,
      color: "from-green-600 to-green-800",
      sites: [
        { name: "Trendyol", url: "https://trendyol.com" },
        { name: "Hepsiburada", url: "https://hepsiburada.com" },
        { name: "N11", url: "https://n11.com" },
        { name: "GittiGidiyor", url: "https://gittigidiyor.com" },
        { name: "Çiçeksepeti", url: "https://ciceksepeti.com" },
        { name: "Teknosa", url: "https://teknosa.com" },
        { name: "MediaMarkt", url: "https://mediamarkt.com.tr" },
        { name: "Vatan Bilgisayar", url: "https://vatanbilgisayar.com" },
        { name: "Boyner", url: "https://boyner.com.tr" },
        { name: "LC Waikiki", url: "https://lcwaikiki.com" },
      ],
    },
    {
      title: "E-Ticaret Global",
      icon: <Globe className="h-5 w-5" />,
      color: "from-purple-600 to-purple-800",
      sites: [
        { name: "Amazon", url: "https://amazon.com" },
        { name: "eBay", url: "https://ebay.com" },
        { name: "AliExpress", url: "https://aliexpress.com" },
        { name: "Alibaba", url: "https://alibaba.com" },
        { name: "Wish", url: "https://wish.com" },
        { name: "Etsy", url: "https://etsy.com" },
        { name: "Walmart", url: "https://walmart.com" },
        { name: "Target", url: "https://target.com" },
        { name: "Best Buy", url: "https://bestbuy.com" },
        { name: "Newegg", url: "https://newegg.com" },
      ],
    },
    {
      title: "Video & Eğlence",
      icon: <Play className="h-5 w-5" />,
      color: "from-red-600 to-red-800",
      sites: [
        { name: "YouTube", url: "https://youtube.com" },
        { name: "Netflix", url: "https://netflix.com" },
        { name: "Twitch", url: "https://twitch.tv" },
        { name: "Disney+", url: "https://disneyplus.com" },
        { name: "Prime Video", url: "https://primevideo.com" },
        { name: "BluTV", url: "https://blutv.com" },
        { name: "Exxen", url: "https://exxen.com" },
        { name: "PuhuTV", url: "https://puhutv.com" },
        { name: "Gain", url: "https://gain.tv" },
        { name: "TRT İzle", url: "https://trtizle.com" },
      ],
    },
    {
      title: "Müzik",
      icon: <Music className="h-5 w-5" />,
      color: "from-pink-600 to-pink-800",
      sites: [
        { name: "Spotify", url: "https://spotify.com" },
        { name: "Apple Music", url: "https://music.apple.com" },
        { name: "YouTube Music", url: "https://music.youtube.com" },
        { name: "SoundCloud", url: "https://soundcloud.com" },
        { name: "Deezer", url: "https://deezer.com" },
        { name: "Fizy", url: "https://fizy.com" },
        { name: "Muud", url: "https://muud.com.tr" },
        { name: "JoyTurk", url: "https://joyturk.com" },
        { name: "PowerTürk", url: "https://powerturk.com" },
        { name: "Radyo D", url: "https://radyod.com" },
      ],
    },
    {
      title: "Oyun",
      icon: <Gamepad2 className="h-5 w-5" />,
      color: "from-indigo-600 to-indigo-800",
      sites: [
        { name: "Steam", url: "https://store.steampowered.com" },
        { name: "Epic Games", url: "https://epicgames.com" },
        { name: "PlayStation", url: "https://playstation.com" },
        { name: "Xbox", url: "https://xbox.com" },
        { name: "Nintendo", url: "https://nintendo.com" },
        { name: "Game Pass", url: "https://gamepass.com" },
        { name: "Origin", url: "https://origin.com" },
        { name: "Uplay", url: "https://uplay.com" },
        { name: "GOG", url: "https://gog.com" },
        { name: "Itch.io", url: "https://itch.io" },
      ],
    },
    {
      title: "Bahis & Casino",
      icon: <Dices className="h-5 w-5" />,
      color: "from-yellow-600 to-yellow-800",
      sites: [
        { name: "Bet365", url: "https://bet365.com" },
        { name: "Betboo", url: "https://betboo.com" },
        { name: "Bets10", url: "https://bets10.com" },
        { name: "Superbahis", url: "https://superbahis.com" },
        { name: "Betway", url: "https://betway.com" },
        { name: "1xBet", url: "https://1xbet.com" },
        { name: "Pokerstars", url: "https://pokerstars.com" },
        { name: "888 Casino", url: "https://888casino.com" },
        { name: "LeoVegas", url: "https://leovegas.com" },
        { name: "Casumo", url: "https://casumo.com" },
      ],
    },
    {
      title: "Bitcoin & Kripto",
      icon: <Bitcoin className="h-5 w-5" />,
      color: "from-orange-600 to-orange-800",
      sites: [
        { name: "Binance", url: "https://binance.com" },
        { name: "Coinbase", url: "https://coinbase.com" },
        { name: "BTCTurk", url: "https://btcturk.com" },
        { name: "Paribu", url: "https://paribu.com" },
        { name: "Bitexen", url: "https://bitexen.com" },
        { name: "Kraken", url: "https://kraken.com" },
        { name: "KuCoin", url: "https://kucoin.com" },
        { name: "Huobi", url: "https://huobi.com" },
        { name: "CoinMarketCap", url: "https://coinmarketcap.com" },
        { name: "CoinGecko", url: "https://coingecko.com" },
      ],
    },
    {
      title: "Spor",
      icon: <Trophy className="h-5 w-5" />,
      color: "from-emerald-600 to-emerald-800",
      sites: [
        { name: "ESPN", url: "https://espn.com" },
        { name: "Fanatik", url: "https://fanatik.com.tr" },
        { name: "Sporx", url: "https://sporx.com" },
        { name: "NTVSpor", url: "https://ntvspor.net" },
        { name: "TRT Spor", url: "https://trtspor.com.tr" },
        { name: "Lig TV", url: "https://ligtv.com.tr" },
        { name: "Spor Toto", url: "https://sportoto.gov.tr" },
        { name: "UEFA", url: "https://uefa.com" },
        { name: "FIFA", url: "https://fifa.com" },
        { name: "NBA", url: "https://nba.com" },
      ],
    },
    {
      title: "Sağlık & Fitness",
      icon: <Heart className="h-5 w-5" />,
      color: "from-rose-600 to-rose-800",
      sites: [
        { name: "WebMD", url: "https://webmd.com" },
        { name: "Sağlık Bakanlığı", url: "https://saglik.gov.tr" },
        { name: "Doktorsitesi", url: "https://doktorsitesi.com" },
        { name: "Medicana", url: "https://medicana.com.tr" },
        { name: "Acıbadem", url: "https://acibadem.com.tr" },
        { name: "MyFitnessPal", url: "https://myfitnesspal.com" },
        { name: "Nike Training", url: "https://nike.com/training" },
        { name: "Fitbit", url: "https://fitbit.com" },
        { name: "Strava", url: "https://strava.com" },
        { name: "Headspace", url: "https://headspace.com" },
      ],
    },
    {
      title: "Otomobil",
      icon: <Car className="h-5 w-5" />,
      color: "from-slate-600 to-slate-800",
      sites: [
        { name: "Sahibinden", url: "https://sahibinden.com" },
        { name: "Arabam.com", url: "https://arabam.com" },
        { name: "Otomoto", url: "https://otomoto.com" },
        { name: "Garaj.com", url: "https://garaj.com" },
        { name: "AutoTrader", url: "https://autotrader.com" },
        { name: "Cars.com", url: "https://cars.com" },
        { name: "BMW", url: "https://bmw.com" },
        { name: "Mercedes", url: "https://mercedes-benz.com" },
        { name: "Toyota", url: "https://toyota.com" },
        { name: "Ford", url: "https://ford.com" },
      ],
    },
    {
      title: "Emlak",
      icon: <Home className="h-5 w-5" />,
      color: "from-teal-600 to-teal-800",
      sites: [
        { name: "Sahibinden Emlak", url: "https://sahibinden.com/emlak" },
        { name: "Emlak Jet", url: "https://emlakjet.com" },
        { name: "Hürriyet Emlak", url: "https://hurriyetemlak.com" },
        { name: "Zingat", url: "https://zingat.com" },
        { name: "Endeksa", url: "https://endeksa.com" },
        { name: "Zillow", url: "https://zillow.com" },
        { name: "Realtor", url: "https://realtor.com" },
        { name: "Century 21", url: "https://century21.com" },
        { name: "RE/MAX", url: "https://remax.com" },
        { name: "Coldwell Banker", url: "https://coldwellbanker.com" },
      ],
    },
    {
      title: "Yemek & Tarif",
      icon: <Utensils className="h-5 w-5" />,
      color: "from-amber-600 to-amber-800",
      sites: [
        { name: "Yemeksepeti", url: "https://yemeksepeti.com" },
        { name: "Getir", url: "https://getir.com" },
        { name: "Trendyol Yemek", url: "https://trendyolyemek.com" },
        { name: "Nefis Yemek", url: "https://nefisyemektarifleri.com" },
        { name: "Lezzet", url: "https://lezzet.com.tr" },
        { name: "AllRecipes", url: "https://allrecipes.com" },
        { name: "Food Network", url: "https://foodnetwork.com" },
        { name: "Tasty", url: "https://tasty.co" },
        { name: "Bon Appétit", url: "https://bonappetit.com" },
        { name: "Epicurious", url: "https://epicurious.com" },
      ],
    },
    {
      title: "Seyahat",
      icon: <Plane className="h-5 w-5" />,
      color: "from-sky-600 to-sky-800",
      sites: [
        { name: "Booking.com", url: "https://booking.com" },
        { name: "Expedia", url: "https://expedia.com" },
        { name: "Airbnb", url: "https://airbnb.com" },
        { name: "Skyscanner", url: "https://skyscanner.com" },
        { name: "Kayak", url: "https://kayak.com" },
        { name: "TripAdvisor", url: "https://tripadvisor.com" },
        { name: "Pegasus", url: "https://flypgs.com" },
        { name: "Turkish Airlines", url: "https://turkishairlines.com" },
        { name: "Jolly Tur", url: "https://jollytur.com" },
        { name: "ETS Tur", url: "https://etstur.com" },
      ],
    },
    {
      title: "Moda & Güzellik",
      icon: <Shirt className="h-5 w-5" />,
      color: "from-fuchsia-600 to-fuchsia-800",
      sites: [
        { name: "Zara", url: "https://zara.com" },
        { name: "H&M", url: "https://hm.com" },
        { name: "Mango", url: "https://mango.com" },
        { name: "Koton", url: "https://koton.com" },
        { name: "DeFacto", url: "https://defacto.com.tr" },
        { name: "Sephora", url: "https://sephora.com" },
        { name: "MAC Cosmetics", url: "https://maccosmetics.com" },
        { name: "Gratis", url: "https://gratis.com" },
        { name: "Watsons", url: "https://watsons.com.tr" },
        { name: "Golden Rose", url: "https://goldenrose.com.tr" },
      ],
    },
    {
      title: "Eğitim",
      icon: <GraduationCap className="h-5 w-5" />,
      color: "from-violet-600 to-violet-800",
      sites: [
        { name: "Khan Academy", url: "https://khanacademy.org" },
        { name: "Coursera", url: "https://coursera.org" },
        { name: "edX", url: "https://edx.org" },
        { name: "Udemy", url: "https://udemy.com" },
        { name: "Duolingo", url: "https://duolingo.com" },
        { name: "Wikipedia", url: "https://wikipedia.org" },
        { name: "YÖK", url: "https://yok.gov.tr" },
        { name: "ÖSYM", url: "https://osym.gov.tr" },
        { name: "MEB", url: "https://meb.gov.tr" },
        { name: "EBA", url: "https://eba.gov.tr" },
      ],
    },
    {
      title: "Finans & Bankacılık",
      icon: <CreditCard className="h-5 w-5" />,
      color: "from-green-700 to-green-900",
      sites: [
        { name: "İş Bankası", url: "https://isbank.com.tr" },
        { name: "Garanti BBVA", url: "https://garanti.com.tr" },
        { name: "Akbank", url: "https://akbank.com" },
        { name: "Yapı Kredi", url: "https://yapikredi.com.tr" },
        { name: "Ziraat Bankası", url: "https://ziraatbank.com.tr" },
        { name: "PayPal", url: "https://paypal.com" },
        { name: "Wise", url: "https://wise.com" },
        { name: "Revolut", url: "https://revolut.com" },
        { name: "N26", url: "https://n26.com" },
        { name: "Investing.com", url: "https://investing.com" },
      ],
    },
    {
      title: "AI & Yapay Zeka",
      icon: <Brain className="h-5 w-5" />,
      color: "from-purple-700 to-purple-900",
      sites: [
        { name: "ChatGPT", url: "https://chat.openai.com" },
        { name: "Claude", url: "https://claude.ai" },
        { name: "Gemini", url: "https://gemini.google.com" },
        { name: "Midjourney", url: "https://midjourney.com" },
        { name: "DALL-E", url: "https://openai.com/dall-e-2" },
        { name: "Stable Diffusion", url: "https://stability.ai" },
        { name: "Hugging Face", url: "https://huggingface.co" },
        { name: "Replicate", url: "https://replicate.com" },
        { name: "RunwayML", url: "https://runwayml.com" },
        { name: "Perplexity", url: "https://perplexity.ai" },
      ],
    },
    {
      title: "Arama Motorları",
      icon: <Search className="h-5 w-5" />,
      color: "from-blue-700 to-blue-900",
      sites: [
        { name: "Google", url: "https://google.com" },
        { name: "Bing", url: "https://bing.com" },
        { name: "DuckDuckGo", url: "https://duckduckgo.com" },
        { name: "Yahoo", url: "https://yahoo.com" },
        { name: "Yandex", url: "https://yandex.com" },
        { name: "Baidu", url: "https://baidu.com" },
        { name: "Startpage", url: "https://startpage.com" },
        { name: "Searx", url: "https://searx.org" },
        { name: "Brave Search", url: "https://search.brave.com" },
        { name: "Ecosia", url: "https://ecosia.org" },
      ],
    },
    {
      title: "Haberler Türkiye",
      icon: <Newspaper className="h-5 w-5" />,
      color: "from-gray-600 to-gray-800",
      sites: [
        { name: "Hürriyet", url: "https://hurriyet.com.tr" },
        { name: "Milliyet", url: "https://milliyet.com.tr" },
        { name: "Sabah", url: "https://sabah.com.tr" },
        { name: "NTV", url: "https://ntv.com.tr" },
        { name: "CNN Türk", url: "https://cnnturk.com" },
        { name: "Habertürk", url: "https://haberturk.com" },
        { name: "Sözcü", url: "https://sozcu.com.tr" },
        { name: "Cumhuriyet", url: "https://cumhuriyet.com.tr" },
        { name: "Ensonhaber", url: "https://ensonhaber.com" },
        { name: "Mynet Haber", url: "https://haber.mynet.com" },
      ],
    },
    {
      title: "Teknoloji",
      icon: <Code className="h-5 w-5" />,
      color: "from-emerald-700 to-emerald-900",
      sites: [
        { name: "GitHub", url: "https://github.com" },
        { name: "Stack Overflow", url: "https://stackoverflow.com" },
        { name: "TechCrunch", url: "https://techcrunch.com" },
        { name: "Wired", url: "https://wired.com" },
        { name: "The Verge", url: "https://theverge.com" },
        { name: "Ars Technica", url: "https://arstechnica.com" },
        { name: "Shiftdelete", url: "https://shiftdelete.net" },
        { name: "Webtekno", url: "https://webtekno.com" },
        { name: "Tamindir", url: "https://tamindir.com" },
        { name: "Chip Online", url: "https://chip.com.tr" },
      ],
    },
    {
      title: "İş & Kariyer",
      icon: <Briefcase className="h-5 w-5" />,
      color: "from-slate-700 to-slate-900",
      sites: [
        { name: "LinkedIn", url: "https://linkedin.com" },
        { name: "Kariyer.net", url: "https://kariyer.net" },
        { name: "Yenibiris", url: "https://yenibiris.com" },
        { name: "SecretCV", url: "https://secretcv.com" },
        { name: "Indeed", url: "https://indeed.com" },
        { name: "Glassdoor", url: "https://glassdoor.com" },
        { name: "İşKur", url: "https://iskur.gov.tr" },
        { name: "Elemanonline", url: "https://elemanonline.com" },
        { name: "İş Arıyorum", url: "https://isariyorum.net" },
        { name: "Monster", url: "https://monster.com.tr" },
      ],
    },
    {
      title: "Fotoğraf & Tasarım",
      icon: <Camera className="h-5 w-5" />,
      color: "from-cyan-600 to-cyan-800",
      sites: [
        { name: "Adobe Creative Cloud", url: "https://adobe.com" },
        { name: "Canva", url: "https://canva.com" },
        { name: "Figma", url: "https://figma.com" },
        { name: "Unsplash", url: "https://unsplash.com" },
        { name: "Pexels", url: "https://pexels.com" },
        { name: "Shutterstock", url: "https://shutterstock.com" },
        { name: "Getty Images", url: "https://gettyimages.com" },
        { name: "Dribbble", url: "https://dribbble.com" },
        { name: "Behance", url: "https://behance.net" },
        { name: "Pinterest", url: "https://pinterest.com" },
      ],
    },
    {
      title: "Podcast",
      icon: <Headphones className="h-5 w-5" />,
      color: "from-indigo-700 to-indigo-900",
      sites: [
        { name: "Spotify Podcasts", url: "https://podcasters.spotify.com" },
        { name: "Apple Podcasts", url: "https://podcasts.apple.com" },
        { name: "Google Podcasts", url: "https://podcasts.google.com" },
        { name: "Castbox", url: "https://castbox.fm" },
        { name: "Podbean", url: "https://podbean.com" },
        { name: "Anchor", url: "https://anchor.fm" },
        { name: "Stitcher", url: "https://stitcher.com" },
        { name: "Overcast", url: "https://overcast.fm" },
        { name: "Pocket Casts", url: "https://pocketcasts.com" },
        { name: "RadioPublic", url: "https://radiopublic.com" },
      ],
    },
    {
      title: "Forum & Topluluk",
      icon: <Users className="h-5 w-5" />,
      color: "from-orange-700 to-orange-900",
      sites: [
        { name: "Reddit", url: "https://reddit.com" },
        { name: "Quora", url: "https://quora.com" },
        { name: "Stack Overflow", url: "https://stackoverflow.com" },
        { name: "Ekşi Sözlük", url: "https://eksisozluk.com" },
        { name: "Donanım Haber", url: "https://donanimhaber.com" },
        { name: "Technopat", url: "https://technopat.net" },
        { name: "4chan", url: "https://4chan.org" },
        { name: "9GAG", url: "https://9gag.com" },
        { name: "Imgur", url: "https://imgur.com" },
        { name: "DeviantArt", url: "https://deviantart.com" },
      ],
    },
    {
      title: "VPN & Güvenlik",
      icon: <Shield className="h-5 w-5" />,
      color: "from-red-700 to-red-900",
      sites: [
        { name: "NordVPN", url: "https://nordvpn.com" },
        { name: "ExpressVPN", url: "https://expressvpn.com" },
        { name: "Surfshark", url: "https://surfshark.com" },
        { name: "CyberGhost", url: "https://cyberghostvpn.com" },
        { name: "ProtonVPN", url: "https://protonvpn.com" },
        { name: "Malwarebytes", url: "https://malwarebytes.com" },
        { name: "Norton", url: "https://norton.com" },
        { name: "McAfee", url: "https://mcafee.com" },
        { name: "Kaspersky", url: "https://kaspersky.com" },
        { name: "Bitdefender", url: "https://bitdefender.com" },
      ],
    },
    {
      title: "Hukuk",
      icon: <Scale className="h-5 w-5" />,
      color: "from-stone-600 to-stone-800",
      sites: [
        { name: "Adalet Bakanlığı", url: "https://adalet.gov.tr" },
        { name: "Türkiye Barolar Birliği", url: "https://barobirlik.org.tr" },
        { name: "e-Devlet", url: "https://turkiye.gov.tr" },
        { name: "Resmi Gazete", url: "https://resmigazete.gov.tr" },
        { name: "Mevzuat", url: "https://mevzuat.gov.tr" },
        { name: "Justia", url: "https://justia.com" },
        { name: "FindLaw", url: "https://findlaw.com" },
        { name: "Avvo", url: "https://avvo.com" },
        { name: "LegalZoom", url: "https://legalzoom.com" },
        { name: "Nolo", url: "https://nolo.com" },
      ],
    },
  ]

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-red-950 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl border-red-800 bg-black/80 backdrop-blur-sm animate-pulse">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-3xl font-bold text-red-100">🚀 The Websites</CardTitle>
            <CardDescription className="text-red-200">Giriş yaparak panele erişin</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-red-100">
                  Kullanıcı Adı
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-gray-900/80 border-red-700 text-red-100 placeholder:text-red-300 transition-all duration-300 focus:scale-105"
                  placeholder="Kullanıcı adınızı girin"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-red-100">
                  Şifre
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-gray-900/80 border-red-700 text-red-100 placeholder:text-red-300 transition-all duration-300 focus:scale-105"
                  placeholder="Şifrenizi girin"
                  required
                />
              </div>
              {error && (
                <div className="text-red-300 text-sm text-center bg-red-900/50 p-2 rounded animate-shake">{error}</div>
              )}
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-red-800 hover:bg-red-700 text-white font-semibold transition-all duration-300 hover:scale-105 disabled:opacity-50"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Giriş yapılıyor...
                  </div>
                ) : (
                  "Giriş Yap"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-red-950 flex">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-80" : "w-16"
        } bg-black/80 backdrop-blur-sm border-r border-red-800/30 transition-all duration-300 flex flex-col`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-red-800/30">
          <div className="flex items-center justify-between">
            {sidebarOpen && <h1 className="text-xl font-bold text-red-100">🚀 The Websites</h1>}
            <Button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              variant="ghost"
              size="sm"
              className="text-red-100 hover:bg-red-800/30"
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex-1 overflow-y-auto p-2">
          {categories.map((category, index) => (
            <button
              key={index}
              onClick={() => setSelectedCategory(index)}
              className={`w-full flex items-center gap-3 p-3 rounded-lg mb-2 transition-all duration-300 hover:scale-105 ${
                selectedCategory === index ? "bg-red-800/50 text-red-100 shadow-lg" : "text-red-200 hover:bg-red-800/30"
              }`}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div>{category.icon}</div>
              {sidebarOpen && (
                <div className="flex-1 text-left">
                  <div className="font-medium">{category.title}</div>
                  <div className="text-xs opacity-70">{category.sites.length} site</div>
                </div>
              )}
            </button>
          ))}
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-red-800/30">
          <Button
            onClick={() => setIsLoggedIn(false)}
            variant="ghost"
            className="w-full text-red-100 hover:bg-red-800/30 transition-all duration-300 hover:scale-105"
          >
            <LogOut className="h-5 w-5" />
            {sidebarOpen && <span className="ml-2">Çıkış Yap</span>}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative overflow-hidden">
        {/* Background Text */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-[20rem] font-black text-gray-600/20 select-none transform -rotate-12 tracking-wider">
            ACHSANTO
          </div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-[12rem] font-black text-gray-500/25 select-none transform rotate-12 mt-40 tracking-widest">
            WAS HERE
          </div>
        </div>

        {/* Content */}
        <div className="relative z-10 p-8 h-full overflow-y-auto">
          {selectedCategory === null ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="text-6xl mb-4">🎯</div>
                <h2 className="text-3xl font-bold text-red-100 mb-2">Hoş Geldiniz!</h2>
                <p className="text-red-300 text-lg">Sol menüden bir kategori seçin</p>
              </div>
            </div>
          ) : (
            <div className="animate-fade-in">
              <div className="mb-8">
                <h2
                  className={`text-4xl font-bold mb-2 bg-gradient-to-r ${categories[selectedCategory].color} bg-clip-text text-transparent`}
                >
                  {categories[selectedCategory].title}
                </h2>
                <p className="text-red-300">{categories[selectedCategory].sites.length} site mevcut</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {categories[selectedCategory].sites.map((site, siteIndex) => (
                  <button
                    key={siteIndex}
                    onClick={() => handleSiteClick(site.url)}
                    className="block p-6 rounded-xl bg-black/40 backdrop-blur-sm border border-red-800/30 text-red-200 hover:bg-red-800/20 hover:text-red-100 transition-all duration-300 hover:scale-110 hover:shadow-2xl transform animate-slide-in cursor-pointer"
                    style={{ animationDelay: `${siteIndex * 100}ms` }}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">🌐</div>
                      <div className="font-semibold">{site.name}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/20 backdrop-blur-sm border-t border-red-800/30">
          <p className="text-center text-red-300 text-sm">
            ⚡ Powered By <span className="text-red-100 font-semibold">Vercel</span> - Owner{" "}
            <span className="text-red-100 font-semibold">Achsanto</span> ⚡
          </p>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slide-in {
          from { opacity: 0; transform: translateX(-50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        
        .animate-fade-in {
          animation: fade-in 0.6s ease-out;
        }
        
        .animate-slide-in {
          animation: slide-in 0.8s ease-out;
        }
        
        .animate-shake {
          animation: shake 0.5s ease-in-out;
        }
      `}</style>
    </div>
  )
}
