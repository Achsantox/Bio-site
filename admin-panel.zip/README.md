# The Websites Panel

Modern ve profesyonel web sitesi koleksiyonu paneli.

## 🚀 Özellikler

- **29 Kategori** - Sosyal medyadan kriptoya kadar her şey
- **290+ Web Sitesi** - En popüler siteler
- **Modern Tasarım** - Sidebar navigasyon
- **Responsive** - Mobil ve desktop uyumlu
- **Animasyonlar** - Smooth geçişler ve efektler
- **Offline Çalışır** - İnternet bağlantısı gerektirmez

## 🔐 Giriş Bilgileri

- **Kullanıcı Adı:** admin
- **Şifre:** achsanto

## 📦 Kurulum

1. Projeyi indirin
2. Terminal'de proje klasörüne gidin
3. Bağımlılıkları yükleyin:
\`\`\`bash
npm install
\`\`\`

4. Geliştirme sunucusunu başlatın:
\`\`\`bash
npm run dev
\`\`\`

5. Tarayıcınızda `http://localhost:3000` adresini açın

## 🏗️ Production Build

\`\`\`bash
npm run build
npm start
\`\`\`

## 📁 Proje Yapısı

\`\`\`
the-websites-panel/
├── app/
│   ├── page.tsx          # Ana sayfa
│   ├── layout.tsx        # Layout
│   └── globals.css       # Global stiller
├── components/
│   └── ui/              # UI bileşenleri
├── package.json
└── README.md
\`\`\`

## 🎨 Kategoriler

- Sosyal Medya
- E-Ticaret (Türkiye & Global)
- Video & Eğlence
- Müzik
- Oyun
- Bahis & Casino
- Bitcoin & Kripto
- Spor
- Sağlık & Fitness
- Otomobil
- Emlak
- Yemek & Tarif
- Seyahat
- Moda & Güzellik
- Eğitim
- Finans & Bankacılık
- AI & Yapay Zeka
- Arama Motorları
- Haberler
- Teknoloji
- İş & Kariyer
- Fotoğraf & Tasarım
- Podcast
- Forum & Topluluk
- VPN & Güvenlik
- Hukuk

## 💻 Teknolojiler

- **Next.js 14** - React framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **Lucide React** - Icons
- **Radix UI** - UI components

## 🎯 Kullanım

1. Giriş yapın (admin/achsanto)
2. Sol menüden kategori seçin
3. İstediğiniz siteye tıklayın
4. Site yeni sekmede açılır

## 🔧 Özelleştirme

`app/page.tsx` dosyasındaki `categories` array'ini düzenleyerek:
- Yeni kategoriler ekleyebilirsiniz
- Mevcut siteleri değiştirebilirsiniz
- Yeni siteler ekleyebilirsiniz

## 📱 Responsive Tasarım

- **Desktop:** Tam sidebar görünümü
- **Tablet:** Daraltılabilir sidebar
- **Mobile:** Hamburger menü

## 🎨 Tema

- **Ana Renk:** Bordo/Kırmızı gradient
- **Arka Plan:** Siyah gradient
- **Accent:** Kategori bazlı renkler

## 🚀 Deploy

Vercel, Netlify veya herhangi bir hosting servisinde deploy edebilirsiniz.

---

**Powered By Vercel - Owner Achsanto**
